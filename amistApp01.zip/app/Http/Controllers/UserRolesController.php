<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserRolesController extends Controller
{
    //
}
